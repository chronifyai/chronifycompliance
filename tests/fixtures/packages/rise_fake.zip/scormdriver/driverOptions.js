function loadDriverOptions(scope) {
  scope.USE_STRICT_SUSPEND_DATA_LIMITS = false;
}